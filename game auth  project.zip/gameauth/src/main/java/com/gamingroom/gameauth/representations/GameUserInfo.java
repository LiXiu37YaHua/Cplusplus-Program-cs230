package com.gamingroom.gameauth.representations;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

public class GameUserInfo {

    @NotNull
    private Integer id;

    @SuppressWarnings("deprecation")
	@NotBlank
    @Length(min = 2, max = 255)
    private String firstName;

    @SuppressWarnings("deprecation")
	@NotBlank
    @Length(min = 2, max = 255)
    private String lastName;

    @Pattern(regexp = ".+@.+\\.[a-z]+")
    private String email;

    public GameUserInfo() {
    }

    public GameUserInfo(Integer id, String firstName, String lastName, String email) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }

    // Getters and setters...

    @Override
    public String toString() {
        return "GameUser [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email + "]";
    }
}
