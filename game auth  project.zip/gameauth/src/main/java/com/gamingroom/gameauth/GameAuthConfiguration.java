package com.gamingroom.gameauth;

import io.dropwizard.Configuration;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.hibernate.validator.constraints.*;
import javax.validation.constraints.*;

public class GameAuthConfiguration extends Configuration {
    // Implement your service configuration here
    // For example, you can add fields, getters, setters, etc.

    @JsonProperty
    private String exampleConfiguration;

    public String getExampleConfiguration() {
        return exampleConfiguration;
    }

    public void setExampleConfiguration(String exampleConfiguration) {
        this.exampleConfiguration = exampleConfiguration;
    }
}