package com.gamingroom.gameauth.controller;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/gameusers")
public class RESTClientController {

    @GET
    @Path("/")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getGameUsers() {
        // ... existing code ...

        // Replace the below return statement with the logic to retrieve the list of game users
        // For example:
        // List<GameUser> gameUsers = someService.getAllGameUsers();
        // return Response.ok(gameUsers).build();

        return Response.status(Response.Status.OK).entity("Endpoint to return list of game users").build();
    }
}
