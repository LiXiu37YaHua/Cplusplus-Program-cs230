package com.gamingroom.gameauth.healthcheck;

import java.util.Map.Entry;
import java.util.Set;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.codahale.metrics.health.HealthCheck.Result;
import com.codahale.metrics.health.HealthCheckRegistry;

@Produces(MediaType.APPLICATION_JSON)
@Path("/status")
public class HealthCheckController {

    private HealthCheckRegistry registry;

    public HealthCheckController(HealthCheckRegistry registry) {
        this.registry = registry;
    }

    @GET
    public Response getStatus() {
        try {
            Set<Entry<String, Result>> healthCheckResults = registry.runHealthChecks().entrySet();
            return Response.ok(healthCheckResults).build();
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                           .entity("Error fetching health check results: " + e.getMessage())
                           .build();
        }
    }
}
