package com.gamingroom.gameauth.model;

public enum GameUserInfo {

}
