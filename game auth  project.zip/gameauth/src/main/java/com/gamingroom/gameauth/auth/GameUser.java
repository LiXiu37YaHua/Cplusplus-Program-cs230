package com.gamingroom.gameauth.auth;

import java.security.Principal;
import java.util.Collections;
import java.util.Set;

public class GameUser implements Principal {
    private final String name;
    private final Set<String> roles;

    public GameUser(String name) {
        this.name = name;
        this.roles = Collections.emptySet(); // Initialize roles as an empty set
    }

    public GameUser(String name, Set<String> roles) {
        this.name = name;
        this.roles = roles != null ? roles : Collections.emptySet(); // Initialize roles as an empty set if null
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return (int) (Math.random() * 100);
    }

    public Set<String> getRoles() {
        return roles;
    }
}
