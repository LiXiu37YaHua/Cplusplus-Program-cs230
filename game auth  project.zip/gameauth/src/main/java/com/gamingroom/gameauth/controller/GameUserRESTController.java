package com.gamingroom.gameauth.controller;


import javax.annotation.security.RolesAllowed;
import javax.validation.Valid;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/gameusers")
@Produces(MediaType.APPLICATION_JSON)
public class GameUserRESTController<GameUser> {

    // ... existing code ...

    // HTTP POST method to create a game user, accessible only to users with the "ADMIN" role
    @POST
    @Path("/create")
    @RolesAllowed("ADMIN")
    public Response createGameUser(@Valid GameUser user) {
		return null;
        // ... existing code ...
    }

    // HTTP GET method to retrieve a game user by ID, accessible only to users with the "USER" role
    @GET
    @Path("/{id}")
    @RolesAllowed("USER")
    public Response getGameUserById(@PathParam("id") int userId) {
		return null;
        //
    }
}
