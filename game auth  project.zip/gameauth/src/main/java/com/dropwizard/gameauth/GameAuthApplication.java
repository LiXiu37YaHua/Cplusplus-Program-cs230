package com.dropwizard.gameauth;

import com.gamingroom.gameauth.GameAuthConfiguration;

import io.dropwizard.Application;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;

public class GameAuthApplication extends Application<GameAuthConfiguration> {

    public static void main(String[] args) throws Exception {
        new GameAuthApplication().run(args);
    }

    @Override
    public void initialize(Bootstrap<GameAuthConfiguration> bootstrap) {
        // Initialization logic, if needed
    }

    @Override
    public void run(GameAuthConfiguration configuration, Environment environment) {
        // Configuration and execution logic go here

        // Example: Register your resources, health checks, etc.
        // environment.jersey().register(new YourResource());
        // environment.healthChecks().register("your-health-check", new YourHealthCheck());
    }
}
