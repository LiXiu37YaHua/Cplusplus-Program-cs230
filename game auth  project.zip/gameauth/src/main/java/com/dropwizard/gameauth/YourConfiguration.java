package com.dropwizard.gameauth;

public interface YourConfiguration {

}
