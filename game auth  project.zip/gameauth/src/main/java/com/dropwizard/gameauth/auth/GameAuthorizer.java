package com.dropwizard.gameauth.auth;

import com.gamingroom.gameauth.auth.GameUser;

import io.dropwizard.auth.Authorizer;

public class GameAuthorizer {
    // Class implementation

    public boolean authorize(GameUser user, String role) {
        // Implement the logic to check if the user has the specified role
        // Example: Check if user.getRoles() contains the specified role
        // Return true if the user has the role, otherwise return false
        return false;
    }
}