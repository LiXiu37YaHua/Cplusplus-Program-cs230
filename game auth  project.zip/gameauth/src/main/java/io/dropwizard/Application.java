package io.dropwizard;

public class Application {

}
