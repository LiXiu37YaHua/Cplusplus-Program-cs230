package io.dropwizard.assets;

public enum AssetsBundle {

}
