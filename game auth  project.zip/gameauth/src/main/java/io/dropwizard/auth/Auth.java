package io.dropwizard.auth;

public @interface Auth {

}
