package io.dropwizard.auth;

public class Authorizer {

}
