package com.dropwizard.helloworld2;

import io.dropwizard.core.Configuration;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.hibernate.validator.constraints.*;
import jakarta.validation.constraints.*;

public class HelloWorldConfiguration extends Configuration {
    // TODO: implement service configuration
}
