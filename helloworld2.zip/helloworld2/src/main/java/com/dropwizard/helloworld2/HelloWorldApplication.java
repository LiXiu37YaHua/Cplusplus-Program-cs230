package com.dropwizard.helloworld2;

import io.dropwizard.core.Application;

import io.dropwizard.core.setup.Bootstrap;
import io.dropwizard.core.setup.Environment;

public class HelloWorldApplication extends Application<HelloWorldConfiguration> {

    public static void main(final String[] args) throws Exception {
        new HelloWorldApplication().run(args);
    }

    @Override
    public void run(final HelloWorldConfiguration configuration,
    final Environment environment) {

    /*
    * This section registers the HelloWorldResource, which is our
    * HTTP end-point with the application. Once this is complete, the
    * end-point will be active when the application server runs. You can
    * register more than one end-point in the environment, but it is a
    * best practice for each end-point to be developed in a separate class.
    */
    environment. jersey().register(
    new HelloWorld2Resource()
    );
    }
}
    